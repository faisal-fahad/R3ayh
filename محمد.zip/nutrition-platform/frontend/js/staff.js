const STATUS_META = {
  preparing: { label: '🟡 قيد التجهيز', cls: 'status-preparing', next: 'ready', nextLabel: 'وضع كجاهزة' },
  ready:     { label: '🟢 جاهزة',       cls: 'status-ready',     next: 'delivered', nextLabel: 'تم التسليم' },
  delivered: { label: '🔵 تم التسليم', cls: 'status-delivered', next: null, nextLabel: null },
};
const PREF_LABELS = { want: '❤️ يرغب به', not_want: 'لا يرغب به', not_eat: '🚫 لا يتناوله', allergy: '⚠️ حساسية' };

let catalog = [];
let currentPatientId = null;
let user = null;

(async function init() {
  user = requireAuth(['staff', 'admin']);
  if (!user) return;
  document.getElementById('chipName').textContent = user.fullName;
  document.getElementById('avatarInitial').textContent = (user.fullName || '؟').charAt(0);
  if (user.role === 'admin') {
    document.querySelector('.brand-sub').textContent = 'مراجعة المرضى (المدير)';
    document.getElementById('backToAdminBtn').style.display = '';
  }

  const { catalog: c } = await Api.catalog();
  catalog = c;
  await loadPatients();
})();

async function loadPatients(search) {
  const { patients } = await Api.patients(search);
  const tbody = document.querySelector('#patientTable tbody');
  tbody.innerHTML = '';
  if (!patients.length) {
    tbody.innerHTML = `<tr><td colspan="5" class="empty-state">لا يوجد مرضى مطابقون.</td></tr>`;
    return;
  }
  patients.forEach((p) => {
    const tr = document.createElement('tr');
    tr.className = 'row-clickable';
    const meal = p.latest_meal_status ? STATUS_META[p.latest_meal_status] : null;
    tr.innerHTML = `
      <td>${p.full_name}</td>
      <td>${p.file_number || '—'}</td>
      <td>${p.last_update ? new Date(p.last_update).toLocaleDateString('ar-SA') : '—'}</td>
      <td>${p.has_allergy ? '<span class="badge badge-allergy">حساسية</span>' : '—'}</td>
      <td>${meal ? `<span class="status-pill ${meal.cls}">${meal.label}</span>` : '—'}</td>
    `;
    tr.addEventListener('click', () => openPatient(p.id, p.full_name, p.file_number));
    tbody.appendChild(tr);
  });
}

document.getElementById('patientSearch').addEventListener('input', (e) => loadPatients(e.target.value));

function showList() {
  document.getElementById('listView').style.display = '';
  document.getElementById('detailView').style.display = 'none';
  currentPatientId = null;
}

async function openPatient(id, name, fileNumber) {
  currentPatientId = id;
  document.getElementById('listView').style.display = 'none';
  document.getElementById('detailView').style.display = '';
  document.getElementById('detailName').textContent = name;
  document.getElementById('detailFile').textContent = fileNumber || '—';

  const [prefsBundle, mealsRes] = await Promise.all([
    Api.patientPreferences(id),
    Api.patientMeals(id),
  ]);
  renderPreferences(prefsBundle);
  renderMeals(mealsRes.meals);
}

function renderPreferences(bundle) {
  const prefs = bundle.preferences || [];
  const allergyItems = [];
  const byCategory = {};

  catalog.forEach((cat) => { byCategory[cat.id] = []; });

  prefs.forEach((p) => {
    const foodItemId = p.foodItemId ?? p.food_item_id;
    for (const cat of catalog) {
      const item = cat.items.find((i) => String(i.id) === String(foodItemId));
      if (item) {
        byCategory[cat.id].push({ name: item.name_ar, status: p.status });
        if (p.status === 'allergy') allergyItems.push(item.name_ar);
        break;
      }
    }
  });

  const allergyBox = document.getElementById('detailAllergy');
  if (allergyItems.length) {
    allergyBox.style.display = 'block';
    allergyBox.innerHTML = `<div class="allergy-banner">⚠️ حساسية غذائية من: ${allergyItems.join('، ')}</div>`;
  } else {
    allergyBox.style.display = 'none';
  }

  const container = document.getElementById('prefContainer');
  container.innerHTML = '';
  catalog.forEach((cat) => {
    const entries = byCategory[cat.id];
    if (!entries.length) return;
    const block = document.createElement('div');
    block.className = 'pref-cat-block';
    block.innerHTML = `<div class="pref-cat-title">${cat.name_ar}</div>` +
      entries.map((e) => `<div class="pref-line"><span>${e.name}</span><span>${PREF_LABELS[e.status]}</span></div>`).join('');
    container.appendChild(block);
  });
  if (!container.innerHTML) container.innerHTML = '<div class="empty-state">لم يحدد المريض تفضيلاته بعد.</div>';

  const generalNote = bundle.generalNote;
  if (generalNote) {
    const noteBlock = document.createElement('div');
    noteBlock.className = 'pref-cat-block';
    noteBlock.innerHTML = `<div class="pref-cat-title">ملاحظات المريض</div><div class="pref-line"><span>${generalNote}</span></div>`;
    container.appendChild(noteBlock);
  }
}

function renderMeals(meals) {
  const container = document.getElementById('mealsContainer');
  if (!meals.length) { container.innerHTML = '<div class="empty-state">لا توجد وجبات بعد.</div>'; return; }
  container.innerHTML = '';
  meals.forEach((meal) => {
    const status = STATUS_META[meal.status];
    const div = document.createElement('div');
    div.className = 'meal-item';
    const items = meal.items || {};
    div.innerHTML = `
      <div class="meal-item-head">
        <strong>${meal.name}</strong>
        <span class="status-pill ${status.cls}">${status.label}</span>
      </div>
      <div style="font-size:13.5px; color:var(--ink-soft);">
        ${Object.values(items).filter(Boolean).join(' · ') || meal.note || ''}
      </div>
      ${status.next ? `<button class="btn btn-ghost btn-sm" style="margin-top:10px;" data-meal-id="${meal.id}" data-next="${status.next}">${status.nextLabel}</button>` : ''}
    `;
    container.appendChild(div);
  });
  container.querySelectorAll('[data-meal-id]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      await Api.setMealStatus(btn.dataset.mealId, btn.dataset.next);
      const mealsRes = await Api.patientMeals(currentPatientId);
      renderMeals(mealsRes.meals);
      showToast('تم تحديث حالة الوجبة.');
    });
  });
}

document.getElementById('newMealBtn').addEventListener('click', () => {
  document.getElementById('mealModal').style.display = 'flex';
});
function closeMealModal() { document.getElementById('mealModal').style.display = 'none'; }

document.getElementById('saveMealBtn').addEventListener('click', async () => {
  const name = document.getElementById('mealName').value.trim();
  if (!name) return showToast('اسم الوجبة مطلوب.');
  const items = {
    carbs: document.getElementById('mealCarbs').value.trim(),
    protein: document.getElementById('mealProtein').value.trim(),
    vegetables: document.getElementById('mealVeg').value.trim(),
  };
  const note = document.getElementById('mealNote').value.trim();
  await Api.createMeal(currentPatientId, { name, items, note });
  closeMealModal();
  ['mealName','mealCarbs','mealProtein','mealVeg','mealNote'].forEach((id) => document.getElementById(id).value = '');
  const mealsRes = await Api.patientMeals(currentPatientId);
  renderMeals(mealsRes.meals);
  showToast('تم إنشاء الوجبة.');
});
