const STATE_META = {
  want:     { label: '❤️ أرغب به',   badgeClass: 'badge-want',    stateClass: 'state-want' },
  not_want: { label: 'لا أرغب به',   badgeClass: 'badge-notwant', stateClass: 'state-notwant' },
  not_eat:  { label: '🚫 لا أتناوله', badgeClass: 'badge-noteat',  stateClass: 'state-noteat' },
  allergy:  { label: '⚠️ حساسية',    badgeClass: 'badge-allergy', stateClass: 'state-allergy' },
};
const STATE_ORDER = ['want', 'not_want', 'not_eat', 'allergy'];

let catalog = [];
let preferenceMap = {};   // foodItemId -> status
let sectionNoteMap = {};  // categoryId -> note

(async function init() {
  const user = requireAuth(['patient']);
  if (!user) return;

  document.getElementById('patientName').textContent = user.fullName;
  document.getElementById('chipName').textContent = user.fullName;
  document.getElementById('fileNumber').textContent = user.fileNumber || '—';
  document.getElementById('usernameMeta').textContent = user.username;
  const initial = (user.fullName || '؟').trim().charAt(0);
  document.getElementById('avatarInitial').textContent = initial;
  document.getElementById('avatarBig').textContent = initial;

  try {
    const [{ catalog: c }, prefsBundle] = await Promise.all([Api.catalog(), Api.myPreferences()]);
    catalog = c;
    (prefsBundle.preferences || []).forEach((p) => { preferenceMap[p.foodItemId ?? p.food_item_id] = p.status; });
    (prefsBundle.sectionNotes || []).forEach((n) => { sectionNoteMap[n.categoryId ?? n.category_id] = n.note; });
    document.getElementById('generalNote').value = prefsBundle.generalNote || '';
    renderSections();
    updateAllergySummary();
  } catch (err) {
    document.getElementById('sectionsContainer').innerHTML = `<div class="empty-state">تعذّر تحميل الأطعمة: ${err.message}</div>`;
  }
})();

function renderSections() {
  const container = document.getElementById('sectionsContainer');
  container.innerHTML = '';

  catalog.forEach((section) => {
    const card = document.createElement('div');
    card.className = 'section-card';
    card.dataset.categoryId = section.id;

    card.innerHTML = `
      <div class="section-head">
        <span class="section-title">${section.name_ar}</span>
        <span class="section-count">${section.items.length} عنصر</span>
      </div>
      <div class="food-grid"></div>
      <div class="section-note">
        <label style="font-size:13px; font-weight:600; color:var(--ink-soft); display:block; margin-bottom:6px;">ملاحظة على ${section.name_ar}</label>
        <textarea rows="2" placeholder="مثال: أفضّله مشويًا..." data-note-for="${section.id}">${sectionNoteMap[section.id] || ''}</textarea>
      </div>
    `;

    const grid = card.querySelector('.food-grid');
    section.items.forEach((item) => grid.appendChild(renderFoodItem(item)));

    container.appendChild(card);
  });

  document.querySelectorAll('[data-note-for]').forEach((el) => {
    el.addEventListener('input', () => { sectionNoteMap[el.dataset.noteFor] = el.value; });
  });
}

function renderFoodItem(item) {
  const wrap = document.createElement('div');
  wrap.className = 'food-item';
  wrap.dataset.itemName = item.name_ar;
  wrap.dataset.itemId = item.id;

  const current = preferenceMap[item.id];
  applyItemVisualState(wrap, current);

  const nameRow = document.createElement('div');
  nameRow.className = 'food-item-name';
  nameRow.innerHTML = `<span>${item.name_ar}</span><span class="badge-slot"></span>`;
  wrap.appendChild(nameRow);

  const optionsRow = document.createElement('div');
  optionsRow.className = 'state-options';
  STATE_ORDER.forEach((state) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'state-btn';
    btn.dataset.state = state;
    btn.textContent = STATE_META[state].label;
    if (current === state) btn.classList.add('active');
    btn.addEventListener('click', () => {
      const isSame = preferenceMap[item.id] === state;
      // النقر على نفس الحالة مرة أخرى يلغي الاختيار — النقر على حالة مختلفة يستبدلها
      // (هذا يمنع تلقائيًا اختيار حالتين متعارضتين لنفس العنصر)
      preferenceMap[item.id] = isSame ? undefined : state;
      if (isSame) delete preferenceMap[item.id];
      optionsRow.querySelectorAll('.state-btn').forEach((b) => b.classList.toggle('active', !isSame && b.dataset.state === state));
      applyItemVisualState(wrap, preferenceMap[item.id]);
      updateAllergySummary();
    });
    optionsRow.appendChild(btn);
  });
  wrap.appendChild(optionsRow);

  return wrap;
}

function applyItemVisualState(wrap, state) {
  wrap.classList.remove('state-want', 'state-notwant', 'state-noteat', 'state-allergy');
  const slot = wrap.querySelector('.badge-slot');
  if (state && STATE_META[state]) {
    wrap.classList.add(STATE_META[state].stateClass);
    if (slot) slot.innerHTML = `<span class="badge ${STATE_META[state].badgeClass}">${STATE_META[state].label}</span>`;
  } else if (slot) {
    slot.innerHTML = '';
  }
}

function updateAllergySummary() {
  const banner = document.getElementById('allergySummary');
  const allergyItems = Object.entries(preferenceMap).filter(([, s]) => s === 'allergy');
  if (!allergyItems.length) { banner.style.display = 'none'; return; }
  const names = allergyItems.map(([id]) => {
    for (const sec of catalog) {
      const it = sec.items.find((i) => String(i.id) === String(id));
      if (it) return it.name_ar;
    }
    return '';
  }).filter(Boolean);
  banner.style.display = 'block';
  banner.innerHTML = `<div class="allergy-banner">⚠️ لديك حساسية مسجّلة من: ${names.join('، ')}</div>`;
}

document.getElementById('searchInput').addEventListener('input', (e) => {
  const q = e.target.value.trim();
  document.querySelectorAll('.food-item').forEach((el) => {
    el.hidden = q && !el.dataset.itemName.includes(q);
  });
  document.querySelectorAll('.section-card').forEach((card) => {
    const visible = card.querySelectorAll('.food-item:not([hidden])').length;
    const anyFoodGrid = card.querySelector('.food-grid');
    if (anyFoodGrid) card.style.display = (q && visible === 0) ? 'none' : '';
  });
});

document.getElementById('saveBtn').addEventListener('click', async () => {
  const btn = document.getElementById('saveBtn');
  btn.disabled = true; btn.textContent = 'جارٍ الحفظ...';
  try {
    const preferences = Object.entries(preferenceMap).map(([foodItemId, status]) => ({ foodItemId: isNaN(foodItemId) ? foodItemId : Number(foodItemId), status }));
    const sectionNotes = Object.entries(sectionNoteMap).map(([categoryId, note]) => ({ categoryId: isNaN(categoryId) ? categoryId : Number(categoryId), note }));
    const generalNote = document.getElementById('generalNote').value;
    await Api.saveMyPreferences({ preferences, sectionNotes, generalNote });
    showToast('تم حفظ تفضيلاتك بنجاح.');
  } catch (err) {
    showToast(err.message || 'تعذّر الحفظ.');
  } finally {
    btn.disabled = false; btn.textContent = 'حفظ تفضيلاتي';
  }
});
