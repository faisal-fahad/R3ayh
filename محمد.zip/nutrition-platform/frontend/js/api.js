/**
 * طبقة الاتصال بالخادم.
 * إذا تعذّر الوصول إلى الخادم الفعلي (مثلاً أثناء معاينة التصميم بدون تشغيل الـ backend)
 * يتم استخدام بيانات تجريبية محلية محفوظة في localStorage حتى تجربة الواجهة تعمل فورًا.
 */
const API_BASE = window.API_BASE_URL || 'http://localhost:4000/api';
const DEMO_KEY = 'renal_demo_db_v1';

function authHeaders() {
  const token = localStorage.getItem('token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function request(path, options = {}) {
  try {
    const res = await fetch(API_BASE + path, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...authHeaders(),
        ...(options.headers || {}),
      },
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new ApiError(data.error || 'حدث خطأ غير متوقع.', res.status);
    return data;
  } catch (err) {
    if (err instanceof ApiError) throw err;
    // تعذّر الاتصال بالخادم — استخدم الوضع التجريبي المحلي
    return DemoBackend.handle(path, options);
  }
}

class ApiError extends Error {
  constructor(message, status) { super(message); this.status = status; }
}

/* ============================================================
   وضع العرض التجريبي (Demo Mode) — يحاكي الخادم داخل المتصفح
   ============================================================ */
const DemoBackend = {
  seedIfNeeded() {
    if (localStorage.getItem(DEMO_KEY)) return;
    const db = {
      categories: [
        { id: 1, key: 'carbs', name_ar: 'الكربوهيدرات', sort_order: 1 },
        { id: 2, key: 'protein', name_ar: 'البروتين', sort_order: 2 },
        { id: 3, key: 'vegetables', name_ar: 'الخضروات', sort_order: 3 },
        { id: 4, key: 'fiber', name_ar: 'الألياف', sort_order: 4 },
        { id: 5, key: 'fats', name_ar: 'الدهون والإضافات', sort_order: 5 },
        { id: 6, key: 'fruits', name_ar: 'الفواكه', sort_order: 6 },
        { id: 7, key: 'drinks', name_ar: 'المشروبات', sort_order: 7 },
        { id: 8, key: 'extras', name_ar: 'الإضافات', sort_order: 8 },
      ],
      items: [
        { id: 1, category_id: 1, name_ar: 'رز أبيض' }, { id: 2, category_id: 1, name_ar: 'رز أحمر' },
        { id: 3, category_id: 1, name_ar: 'مكرونة' }, { id: 4, category_id: 1, name_ar: 'بطاطس' },
        { id: 5, category_id: 1, name_ar: 'خبز' },
        { id: 6, category_id: 2, name_ar: 'دجاج مشوي' }, { id: 7, category_id: 2, name_ar: 'دجاج على الفحم' },
        { id: 8, category_id: 2, name_ar: 'لحم' }, { id: 9, category_id: 2, name_ar: 'سمك' },
        { id: 10, category_id: 2, name_ar: 'بيض' },
        { id: 11, category_id: 3, name_ar: 'خس' }, { id: 12, category_id: 3, name_ar: 'خيار' },
        { id: 13, category_id: 3, name_ar: 'جزر' }, { id: 14, category_id: 3, name_ar: 'بروكلي' },
        { id: 15, category_id: 3, name_ar: 'كوسة' }, { id: 16, category_id: 3, name_ar: 'طماطم' },
        { id: 17, category_id: 3, name_ar: 'فاصوليا' },
        { id: 18, category_id: 4, name_ar: 'شوفان' }, { id: 19, category_id: 4, name_ar: 'خبز أسمر' },
        { id: 20, category_id: 5, name_ar: 'زيت الزيتون' }, { id: 21, category_id: 5, name_ar: 'صوص' },
        { id: 22, category_id: 6, name_ar: 'تفاح' }, { id: 23, category_id: 6, name_ar: 'عنب' },
        { id: 24, category_id: 6, name_ar: 'تمر' },
        { id: 25, category_id: 7, name_ar: 'ماء' }, { id: 26, category_id: 7, name_ar: 'عصير طبيعي' },
        { id: 27, category_id: 8, name_ar: 'بهارات' }, { id: 28, category_id: 8, name_ar: 'صوص إضافي' },
      ],
      users: [
        { id: 'admin-1', username: 'admin', password: 'Admin@12345', role: 'admin', full_name: 'مدير النظام', is_active: true },
        { id: 'staff-1', username: 'staff', password: 'Staff@12345', role: 'staff', full_name: 'أحمد الموظف', is_active: true,
          permissions: ['view_patients','view_preferences','view_allergies','create_meals','edit_meals','change_meal_status'] },
        { id: 'patient-1', username: 'patient', password: 'Patient@12345', role: 'patient', full_name: 'سلطان العتيبي',
          file_number: 'RN-1042', is_active: true },
      ],
      preferences: {},   // patientId -> [{foodItemId, status}]
      sectionNotes: {},  // patientId -> [{categoryId, note}]
      generalNotes: {},  // patientId -> note
      meals: [],         // {id, patient_id, name, items, note, status, created_at}
      auditLogs: [],
    };
    localStorage.setItem(DEMO_KEY, JSON.stringify(db));
  },

  db() { this.seedIfNeeded(); return JSON.parse(localStorage.getItem(DEMO_KEY)); },
  save(db) { localStorage.setItem(DEMO_KEY, JSON.stringify(db)); },
  log(db, actor, action, details) {
    db.auditLogs.unshift({ id: Date.now(), username: actor?.username, role: actor?.role, action, details, created_at: new Date().toISOString() });
  },
  currentActor() {
    const raw = localStorage.getItem('demo_user');
    return raw ? JSON.parse(raw) : null;
  },

  async handle(path, options) {
    const db = this.db();
    const method = options.method || 'GET';
    const body = options.body ? JSON.parse(options.body) : {};
    const actor = this.currentActor();

    // تسجيل الدخول
    if (path === '/auth/login' && method === 'POST') {
      const user = db.users.find((u) => u.username === body.username && u.is_active);
      if (!user || user.password !== body.password) throw new ApiError('اسم المستخدم أو كلمة المرور غير صحيحة.', 401);
      const token = 'demo.' + user.id;
      const actorObj = { id: user.id, username: user.username, role: user.role, fullName: user.full_name };
      localStorage.setItem('demo_user', JSON.stringify(actorObj));
      this.log(db, actorObj, 'تسجيل دخول'); this.save(db);
      return { token, user: { id: user.id, username: user.username, role: user.role, fullName: user.full_name, fileNumber: user.file_number, permissions: user.permissions || [] } };
    }

    if (path === '/catalog') {
      return { catalog: db.categories.sort((a,b)=>a.sort_order-b.sort_order).map((c) => ({ ...c, items: db.items.filter((i) => i.category_id === c.id) })) };
    }

    if (path === '/me/preferences' && method === 'GET') {
      return {
        preferences: db.preferences[actor.id] || [],
        sectionNotes: db.sectionNotes[actor.id] || [],
        generalNote: db.generalNotes[actor.id] || '',
      };
    }

    if (path.match(/^\/patients\/[^/]+\/preferences$/)) {
      const patientId = path.split('/')[2];
      if (method === 'PUT') {
        db.preferences[patientId] = body.preferences;
        this.log(db, actor, 'تعديل تفضيلات مريض', patientId); this.save(db);
        return { message: 'تم التحديث' };
      }
      return { preferences: db.preferences[patientId] || [], sectionNotes: db.sectionNotes[patientId] || [], generalNote: db.generalNotes[patientId] || '' };
    }

    if (path === '/me/preferences' && method === 'PUT') {
      db.preferences[actor.id] = body.preferences;
      db.sectionNotes[actor.id] = body.sectionNotes;
      db.generalNotes[actor.id] = body.generalNote;
      this.log(db, actor, 'حفظ تفضيلات الوجبة'); this.save(db);
      return { message: 'تم حفظ تفضيلاتك بنجاح.' };
    }

    if (path.startsWith('/patients') && method === 'GET') {
      const patients = db.users.filter((u) => u.role === 'patient').map((p) => ({
        id: p.id, full_name: p.full_name, file_number: p.file_number, is_active: p.is_active,
        has_allergy: (db.preferences[p.id] || []).some((pr) => pr.status === 'allergy'),
        latest_meal_status: (db.meals.filter((m) => m.patient_id === p.id).slice(-1)[0] || {}).status || null,
      }));
      return { patients };
    }

    if (path.startsWith('/meals/patients/') && method === 'GET') {
      const patientId = path.split('/')[3];
      return { meals: db.meals.filter((m) => m.patient_id === patientId).sort((a,b)=> new Date(b.created_at)-new Date(a.created_at)) };
    }

    if (path.startsWith('/meals/patients/') && method === 'POST') {
      const patientId = path.split('/')[3];
      const meal = { id: Date.now(), patient_id: patientId, name: body.name, items: body.items, note: body.note, status: 'preparing', created_at: new Date().toISOString() };
      db.meals.push(meal);
      this.log(db, actor, 'إنشاء وجبة لمريض', body.name); this.save(db);
      return { meal };
    }

    if (path.match(/^\/meals\/\d+\/status$/) && method === 'PATCH') {
      const id = Number(path.split('/')[2]);
      const meal = db.meals.find((m) => m.id === id);
      meal.status = body.status;
      this.log(db, actor, 'تغيير حالة الوجبة', body.status); this.save(db);
      return { meal };
    }

    if (path === '/staff' && method === 'GET') {
      const staff = db.users.filter((u) => u.role === 'staff');
      return { staff, availablePermissions: ['view_patients','edit_patients','view_preferences','edit_preferences','view_allergies','create_meals','edit_meals','change_meal_status','manage_foods'] };
    }

    if (path === '/staff' && method === 'POST') {
      const user = { id: 'staff-' + Date.now(), username: body.username, password: body.password, role: 'staff', full_name: body.fullName, is_active: true, permissions: body.permissions || [] };
      db.users.push(user);
      this.log(db, actor, 'إضافة موظف جديد', body.fullName); this.save(db);
      return { staff: user };
    }

    if (path === '/patients' && method === 'POST') {
      const user = { id: 'patient-' + Date.now(), username: body.username, password: body.password, role: 'patient', full_name: body.fullName, file_number: body.fileNumber, is_active: true };
      db.users.push(user);
      this.log(db, actor, 'إضافة مريض جديد', body.fullName); this.save(db);
      return { patient: user };
    }

    if (path === '/audit-logs') {
      return { logs: db.auditLogs };
    }

    if (path.match(/^\/items$/) && method === 'POST') {
      const item = { id: Date.now(), category_id: body.categoryId, name_ar: body.nameAr };
      db.items.push(item); this.save(db);
      return { item };
    }

    throw new ApiError('هذا الإجراء غير متاح في وضع العرض التجريبي.', 400);
  },
};

const Api = {
  login: (username, password) => request('/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) }),
  catalog: () => request('/catalog'),
  myPreferences: () => request('/me/preferences'),
  saveMyPreferences: (payload) => request('/me/preferences', { method: 'PUT', body: JSON.stringify(payload) }),
  patients: (search) => request('/patients' + (search ? `?search=${encodeURIComponent(search)}` : '')),
  patientPreferences: (id) => request(`/patients/${id}/preferences`),
  updatePatientPreferences: (id, preferences) => request(`/patients/${id}/preferences`, { method: 'PUT', body: JSON.stringify({ preferences }) }),
  patientMeals: (id) => request(`/meals/patients/${id}`),
  createMeal: (id, meal) => request(`/meals/patients/${id}`, { method: 'POST', body: JSON.stringify(meal) }),
  setMealStatus: (id, status) => request(`/meals/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),
  staffList: () => request('/staff'),
  createStaff: (staff) => request('/staff', { method: 'POST', body: JSON.stringify(staff) }),
  createPatient: (patient) => request('/patients', { method: 'POST', body: JSON.stringify(patient) }),
  auditLogs: () => request('/audit-logs'),
  addFoodItem: (categoryId, nameAr) => request('/items', { method: 'POST', body: JSON.stringify({ categoryId, nameAr }) }),
};

function requireAuth(roles) {
  const raw = localStorage.getItem('user');
  if (!raw) { window.location.href = 'login.html'; return null; }
  const user = JSON.parse(raw);
  if (roles && !roles.includes(user.role)) { window.location.href = 'login.html'; return null; }
  return user;
}

function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  localStorage.removeItem('demo_user');
  window.location.href = 'login.html';
}

function showToast(message) {
  let toast = document.querySelector('.toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => toast.classList.remove('show'), 2600);
}
