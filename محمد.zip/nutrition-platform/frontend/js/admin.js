const PERMISSION_LABELS = {
  view_patients: 'مشاهدة المرضى',
  edit_patients: 'تعديل المرضى',
  view_preferences: 'مشاهدة التفضيلات',
  edit_preferences: 'تعديل التفضيلات',
  view_allergies: 'مشاهدة الحساسية',
  create_meals: 'إنشاء الوجبات',
  edit_meals: 'تعديل الوجبات',
  change_meal_status: 'تغيير حالة الوجبة',
  manage_foods: 'إدارة الأطعمة',
};

(async function init() {
  const user = requireAuth(['admin']);
  if (!user) return;
  document.getElementById('chipName').textContent = user.fullName;
  document.getElementById('avatarInitial').textContent = (user.fullName || '؟').charAt(0);

  setupTabs();
  await loadPatients();
  await loadStaff();
  await loadFoods();
  await loadAudit();
})();

function setupTabs() {
  document.querySelectorAll('.tab-link').forEach((link) => {
    link.addEventListener('click', (e) => {
      if (!link.dataset.tab) return; // روابط خارجية مثل "مراجعة المرضى"
      e.preventDefault();
      document.querySelectorAll('.tab-link').forEach((l) => l.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach((p) => p.classList.remove('active'));
      link.classList.add('active');
      document.getElementById('tab-' + link.dataset.tab).classList.add('active');
    });
  });
}

function closeModal(id) { document.getElementById(id).style.display = 'none'; }

/* ---------------- المرضى ---------------- */
async function loadPatients() {
  const { patients } = await Api.patients();
  const tbody = document.querySelector('#patientsTable tbody');
  tbody.innerHTML = patients.map((p) => `
    <tr>
      <td>${p.full_name}</td>
      <td>${p.username || '—'}</td>
      <td>${p.file_number || '—'}</td>
      <td>${p.is_active === false ? '<span class="status-pill status-delivered">معطّل</span>' : '<span class="status-pill status-ready">نشط</span>'}</td>
    </tr>`).join('') || '<tr><td colspan="4" class="empty-state">لا يوجد مرضى بعد.</td></tr>';
}

document.getElementById('newPatientBtn').addEventListener('click', () => document.getElementById('patientModal').style.display = 'flex');
document.getElementById('savePatientBtn').addEventListener('click', async () => {
  const fullName = document.getElementById('pFullName').value.trim();
  const username = document.getElementById('pUsername').value.trim();
  const password = document.getElementById('pPassword').value;
  const fileNumber = document.getElementById('pFileNumber').value.trim();
  if (!fullName || !username || password.length < 8) return showToast('تحقق من الحقول — كلمة المرور 8 خانات على الأقل.');
  try {
    await Api.createPatient({ fullName, username, password, fileNumber });
    closeModal('patientModal');
    ['pFullName','pUsername','pPassword','pFileNumber'].forEach((id) => document.getElementById(id).value = '');
    await loadPatients();
    showToast('تم إنشاء حساب المريض.');
  } catch (err) { showToast(err.message); }
});

/* ---------------- الموظفون ---------------- */
async function loadStaff() {
  const { staff, availablePermissions } = await Api.staffList();
  const grid = document.getElementById('permGrid');
  grid.innerHTML = (availablePermissions || Object.keys(PERMISSION_LABELS)).map((key) => `
    <label class="perm-check"><input type="checkbox" value="${key}"> ${PERMISSION_LABELS[key] || key}</label>
  `).join('');

  const tbody = document.querySelector('#staffTable tbody');
  tbody.innerHTML = staff.map((s) => `
    <tr>
      <td>${s.full_name}</td>
      <td>${s.username || '—'}</td>
      <td class="permission-badges">${(s.permissions || []).map((p) => `<span>${PERMISSION_LABELS[p] || p}</span>`).join('') || '—'}</td>
      <td>${s.is_active === false ? '<span class="status-pill status-delivered">معطّل</span>' : '<span class="status-pill status-ready">نشط</span>'}</td>
    </tr>`).join('') || '<tr><td colspan="4" class="empty-state">لا يوجد موظفون بعد.</td></tr>';
}

document.getElementById('newStaffBtn').addEventListener('click', () => document.getElementById('staffModal').style.display = 'flex');
document.getElementById('saveStaffBtn').addEventListener('click', async () => {
  const fullName = document.getElementById('sFullName').value.trim();
  const username = document.getElementById('sUsername').value.trim();
  const password = document.getElementById('sPassword').value;
  const permissions = Array.from(document.querySelectorAll('#permGrid input:checked')).map((i) => i.value);
  if (!fullName || !username || password.length < 8) return showToast('تحقق من الحقول — كلمة المرور 8 خانات على الأقل.');
  try {
    await Api.createStaff({ fullName, username, password, permissions });
    closeModal('staffModal');
    ['sFullName','sUsername','sPassword'].forEach((id) => document.getElementById(id).value = '');
    document.querySelectorAll('#permGrid input').forEach((i) => i.checked = false);
    await loadStaff();
    showToast('تم إنشاء حساب الموظف.');
  } catch (err) { showToast(err.message); }
});

/* ---------------- الأطعمة ---------------- */
async function loadFoods() {
  const { catalog } = await Api.catalog();
  const container = document.getElementById('foodsContainer');
  container.innerHTML = catalog.map((cat) => `
    <div class="cat-block" data-cat-id="${cat.id}">
      <div class="cat-block-head"><strong>${cat.name_ar}</strong><span class="section-count">${cat.items.length} عنصر</span></div>
      <div class="cat-items-inline">${cat.items.map((i) => `<span>${i.name_ar}</span>`).join('') || '—'}</div>
      <div class="add-item-row">
        <input type="text" placeholder="اسم عنصر جديد..." data-add-input>
        <button class="btn btn-ghost btn-sm" data-add-btn>+ إضافة</button>
      </div>
    </div>
  `).join('');

  container.querySelectorAll('.cat-block').forEach((block) => {
    const catId = block.dataset.catId;
    const input = block.querySelector('[data-add-input]');
    block.querySelector('[data-add-btn]').addEventListener('click', async () => {
      const name = input.value.trim();
      if (!name) return;
      await Api.addFoodItem(isNaN(catId) ? catId : Number(catId), name);
      input.value = '';
      await loadFoods();
      showToast('تمت إضافة العنصر.');
    });
  });
}

/* ---------------- سجل النشاطات ---------------- */
async function loadAudit() {
  const { logs } = await Api.auditLogs();
  const tbody = document.querySelector('#auditTable tbody');
  tbody.innerHTML = logs.map((l) => `
    <tr>
      <td>${l.username || '—'}</td>
      <td>${l.role || '—'}</td>
      <td>${l.action}</td>
      <td>${l.details || '—'}</td>
      <td>${new Date(l.created_at).toLocaleString('ar-SA')}</td>
    </tr>`).join('') || '<tr><td colspan="5" class="empty-state">لا يوجد نشاط مسجّل بعد.</td></tr>';
}
