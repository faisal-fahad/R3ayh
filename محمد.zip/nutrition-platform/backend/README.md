# الخادم الخلفي — منصة تخصيص وجبات مرضى الكلى

## التشغيل

```bash
cd backend
cp .env.example .env      # ثم عدّل DATABASE_URL و JWT_SECRET
npm install
npm run migrate           # ينشئ الجداول ويزرع الأقسام والعناصر الأولية
npm run seed:admin -- admin "Admin@12345" "مدير النظام"
npm run dev                # أو npm start
```

الخادم يعمل افتراضيًا على المنفذ 4000.

## الصلاحيات المتاحة للموظفين
`view_patients, edit_patients, view_preferences, edit_preferences, view_allergies, create_meals, edit_meals, change_meal_status, manage_foods`

## أهم المسارات
- `POST /api/auth/login`
- `GET  /api/catalog` — الأقسام والعناصر الغذائية
- `GET/PUT /api/me/preferences` — تفضيلات المريض نفسه
- `GET  /api/patients` — قائمة المرضى (صلاحية view_patients)
- `GET/PUT /api/patients/:id/preferences`
- `POST /api/patients` — إنشاء حساب مريض (مدير)
- `POST /api/staff` — إنشاء حساب موظف وصلاحياته (مدير)
- `POST /api/meals/patients/:patientId` — إنشاء وجبة
- `PATCH /api/meals/:id/status` — تغيير حالة الوجبة
- `GET  /api/audit-logs` — سجل النشاطات (مدير)

## ملاحظات أمنية
- لا يوجد تسجيل حساب ذاتي؛ كل الحسابات ينشئها المدير.
- كلمات المرور مخزّنة بتجزئة bcrypt (12 جولة).
- الجلسات عبر JWT قصير العمر (8 ساعات افتراضيًا).
- كل عملية حساسة تُسجَّل في `audit_logs`.
- لا يستطيع أي موظف الوصول إلا للصلاحيات الممنوحة له صراحة من المدير.
