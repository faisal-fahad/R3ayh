/**
 * ينشئ أول حساب مدير في النظام.
 * الاستخدام: node src/scripts/seedAdmin.js <username> <password> <fullName>
 * مثال:      node src/scripts/seedAdmin.js admin "Admin@12345" "مدير النظام"
 */
require('dotenv').config();
const pool = require('../db/pool');
const { hashPassword } = require('../utils/password');

async function main() {
  const [username, password, fullName] = process.argv.slice(2);
  if (!username || !password) {
    console.error('الاستخدام: node src/scripts/seedAdmin.js <username> <password> <fullName>');
    process.exit(1);
  }
  if (password.length < 8) {
    console.error('كلمة المرور يجب ألا تقل عن 8 خانات.');
    process.exit(1);
  }

  const passwordHash = await hashPassword(password);
  await pool.query(
    `INSERT INTO users (username, password_hash, role, full_name)
     VALUES ($1, $2, 'admin', $3)
     ON CONFLICT (username) DO UPDATE SET password_hash = EXCLUDED.password_hash`,
    [username, passwordHash, fullName || 'مدير النظام']
  );

  console.log(`تم إنشاء/تحديث حساب المدير "${username}" بنجاح.`);
  await pool.end();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
