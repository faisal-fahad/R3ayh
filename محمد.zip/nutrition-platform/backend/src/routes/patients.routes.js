const express = require('express');
const pool = require('../db/pool');
const { authenticate, requireRole } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { hashPassword } = require('../utils/password');
const { logActivity } = require('../utils/audit');

const router = express.Router();
router.use(authenticate);

// المريض يقرأ بياناته الأساسية الخاصة
router.get('/me', requireRole('patient'), async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT id, username, full_name, file_number FROM users WHERE id = $1`,
      [req.user.id]
    );
    res.json({ patient: rows[0] });
  } catch (err) {
    next(err);
  }
});

// قائمة المرضى — للموظف (بصلاحية) أو المدير
router.get('/', requirePermission('view_patients'), async (req, res, next) => {
  try {
    const search = req.query.search ? `%${req.query.search}%` : null;
    const { rows } = await pool.query(
      `SELECT p.id, p.full_name, p.file_number, p.is_active,
              (SELECT max(updated_at) FROM preferences WHERE patient_id = p.id) AS last_update,
              EXISTS (SELECT 1 FROM preferences WHERE patient_id = p.id AND status='allergy') AS has_allergy,
              (SELECT status FROM meals WHERE patient_id = p.id ORDER BY created_at DESC LIMIT 1) AS latest_meal_status
       FROM users p
       WHERE p.role = 'patient'
         AND ($1::text IS NULL OR p.full_name ILIKE $1 OR p.file_number ILIKE $1)
       ORDER BY p.full_name`,
      [search]
    );
    res.json({ patients: rows });
  } catch (err) {
    next(err);
  }
});

// تفاصيل مريض واحد
router.get('/:id', requirePermission('view_patients'), async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT id, username, full_name, file_number, email, is_active, created_at
       FROM users WHERE id = $1 AND role = 'patient'`,
      [req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error: 'المريض غير موجود.' });
    res.json({ patient: rows[0] });
  } catch (err) {
    next(err);
  }
});

// إنشاء حساب مريض جديد — مدير فقط
router.post('/', requireRole('admin'), async (req, res, next) => {
  try {
    const { username, password, fullName, fileNumber, email } = req.body;
    if (!username || !password || !fullName) {
      return res.status(400).json({ error: 'اسم المستخدم وكلمة المرور والاسم الكامل مطلوبة.' });
    }
    const passwordHash = await hashPassword(password);
    const { rows } = await pool.query(
      `INSERT INTO users (username, password_hash, role, full_name, file_number, email, created_by)
       VALUES ($1,$2,'patient',$3,$4,$5,$6)
       RETURNING id, username, full_name, file_number, email, is_active`,
      [username, passwordHash, fullName, fileNumber || null, email || null, req.user.id]
    );
    await logActivity(req.user, 'إضافة مريض جديد', fullName);
    res.status(201).json({ patient: rows[0] });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'اسم المستخدم أو رقم الملف مستخدم مسبقًا.' });
    next(err);
  }
});

// تعديل بيانات مريض — مدير، أو موظف بصلاحية edit_patients
router.put('/:id', requirePermission('edit_patients'), async (req, res, next) => {
  try {
    const { fullName, fileNumber, email } = req.body;
    const { rows } = await pool.query(
      `UPDATE users SET full_name = COALESCE($1, full_name),
        file_number = COALESCE($2, file_number), email = COALESCE($3, email),
        updated_at = now()
       WHERE id = $4 AND role = 'patient'
       RETURNING id, username, full_name, file_number, email, is_active`,
      [fullName, fileNumber, email, req.params.id]
    );
    await logActivity(req.user, 'تعديل بيانات مريض', rows[0]?.full_name);
    res.json({ patient: rows[0] });
  } catch (err) {
    next(err);
  }
});

// تفعيل/تعطيل حساب مريض — مدير فقط
router.patch('/:id/status', requireRole('admin'), async (req, res, next) => {
  try {
    const { isActive } = req.body;
    const { rows } = await pool.query(
      `UPDATE users SET is_active = $1, updated_at = now() WHERE id = $2 RETURNING id, full_name, is_active`,
      [isActive, req.params.id]
    );
    await logActivity(req.user, isActive ? 'تفعيل حساب مريض' : 'تعطيل حساب مريض', rows[0]?.full_name);
    res.json({ patient: rows[0] });
  } catch (err) {
    next(err);
  }
});

// إعادة تعيين اسم المستخدم أو كلمة المرور — مدير فقط
router.patch('/:id/credentials', requireRole('admin'), async (req, res, next) => {
  try {
    const { username, password } = req.body;
    const fields = [];
    const values = [];
    let i = 1;
    if (username) { fields.push(`username = $${i++}`); values.push(username); }
    if (password) { fields.push(`password_hash = $${i++}`); values.push(await hashPassword(password)); }
    if (!fields.length) return res.status(400).json({ error: 'لا يوجد ما يتم تحديثه.' });
    values.push(req.params.id);
    const { rows } = await pool.query(
      `UPDATE users SET ${fields.join(', ')}, updated_at = now() WHERE id = $${i} RETURNING id, username`,
      values
    );
    await logActivity(req.user, 'تحديث بيانات دخول مريض', rows[0]?.username);
    res.json({ patient: rows[0] });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'اسم المستخدم مستخدم مسبقًا.' });
    next(err);
  }
});

module.exports = router;
