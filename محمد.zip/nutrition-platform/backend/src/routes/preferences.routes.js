const express = require('express');
const pool = require('../db/pool');
const { authenticate, requireRole } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { logActivity } = require('../utils/audit');

const router = express.Router();
router.use(authenticate);

const VALID_STATUSES = ['want', 'not_want', 'not_eat', 'allergy'];

async function getPreferencesBundle(patientId) {
  const [{ rows: prefs }, { rows: sectionNotes }, { rows: generalNote }] = await Promise.all([
    pool.query('SELECT food_item_id, status FROM preferences WHERE patient_id = $1', [patientId]),
    pool.query('SELECT category_id, note FROM section_notes WHERE patient_id = $1', [patientId]),
    pool.query('SELECT note FROM general_notes WHERE patient_id = $1', [patientId]),
  ]);
  return {
    preferences: prefs,
    sectionNotes,
    generalNote: generalNote[0]?.note || '',
  };
}

// المريض يقرأ تفضيلاته الخاصة
router.get('/me/preferences', requireRole('patient'), async (req, res, next) => {
  try {
    res.json(await getPreferencesBundle(req.user.id));
  } catch (err) {
    next(err);
  }
});

// المريض يحفظ (أو يحدّث) تفضيلاته دفعة واحدة
router.put('/me/preferences', requireRole('patient'), async (req, res, next) => {
  const client = await pool.connect();
  try {
    const { preferences = [], sectionNotes = [], generalNote } = req.body;

    for (const p of preferences) {
      if (!VALID_STATUSES.includes(p.status)) {
        return res.status(400).json({ error: 'حالة تفضيل غير صالحة.' });
      }
    }

    await client.query('BEGIN');

    for (const p of preferences) {
      await client.query(
        `INSERT INTO preferences (patient_id, food_item_id, status, updated_at)
         VALUES ($1,$2,$3, now())
         ON CONFLICT (patient_id, food_item_id)
         DO UPDATE SET status = EXCLUDED.status, updated_at = now()`,
        [req.user.id, p.foodItemId, p.status]
      );
    }

    for (const n of sectionNotes) {
      await client.query(
        `INSERT INTO section_notes (patient_id, category_id, note, updated_at)
         VALUES ($1,$2,$3, now())
         ON CONFLICT (patient_id, category_id)
         DO UPDATE SET note = EXCLUDED.note, updated_at = now()`,
        [req.user.id, n.categoryId, n.note || '']
      );
    }

    if (typeof generalNote === 'string') {
      await client.query(
        `INSERT INTO general_notes (patient_id, note, updated_at) VALUES ($1,$2, now())
         ON CONFLICT (patient_id) DO UPDATE SET note = EXCLUDED.note, updated_at = now()`,
        [req.user.id, generalNote]
      );
    }

    await client.query('COMMIT');
    await logActivity(req.user, 'حفظ تفضيلات الوجبة');
    res.json({ message: 'تم حفظ تفضيلاتك بنجاح.' });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
});

// الموظف/المدير يقرأ تفضيلات مريض معيّن
router.get(
  '/patients/:patientId/preferences',
  requirePermission('view_preferences'),
  async (req, res, next) => {
    try {
      const bundle = await getPreferencesBundle(req.params.patientId);
      // إخفاء تفاصيل الحساسية عن من لا يملك صلاحية مشاهدتها تحديدًا
      if (req.user.role === 'staff') {
        const { rows } = await pool.query(
          `SELECT 1 FROM staff_permissions WHERE user_id=$1 AND permission_key='view_allergies'`,
          [req.user.id]
        );
        if (rows.length === 0) {
          bundle.preferences = bundle.preferences.filter((p) => p.status !== 'allergy');
        }
      }
      res.json(bundle);
    } catch (err) {
      next(err);
    }
  }
);

// الموظف صاحب صلاحية edit_preferences يستطيع تعديل تفضيلات مريض نيابة عنه
router.put(
  '/patients/:patientId/preferences',
  requirePermission('edit_preferences'),
  async (req, res, next) => {
    try {
      const { preferences = [] } = req.body;
      for (const p of preferences) {
        if (!VALID_STATUSES.includes(p.status)) {
          return res.status(400).json({ error: 'حالة تفضيل غير صالحة.' });
        }
        await pool.query(
          `INSERT INTO preferences (patient_id, food_item_id, status, updated_at)
           VALUES ($1,$2,$3, now())
           ON CONFLICT (patient_id, food_item_id)
           DO UPDATE SET status = EXCLUDED.status, updated_at = now()`,
          [req.params.patientId, p.foodItemId, p.status]
        );
      }
      await logActivity(req.user, 'تعديل تفضيلات مريض', `patient=${req.params.patientId}`);
      res.json({ message: 'تم تحديث تفضيلات المريض.' });
    } catch (err) {
      next(err);
    }
  }
);

module.exports = router;
