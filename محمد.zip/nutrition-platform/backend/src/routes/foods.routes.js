const express = require('express');
const pool = require('../db/pool');
const { authenticate, requireRole } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { logActivity } = require('../utils/audit');

const router = express.Router();
router.use(authenticate);

// جلب كل الأقسام مع عناصرها — متاح لأي مستخدم مسجّل دخول (مريض/موظف/مدير)
router.get('/catalog', async (req, res, next) => {
  try {
    const { rows: categories } = await pool.query(
      `SELECT id, key, name_ar, sort_order FROM categories
       WHERE is_active = true ORDER BY sort_order`
    );
    const { rows: items } = await pool.query(
      `SELECT id, category_id, name_ar, sort_order FROM food_items
       WHERE is_active = true ORDER BY sort_order`
    );
    const catalog = categories.map((c) => ({
      ...c,
      items: items.filter((i) => i.category_id === c.id),
    }));
    res.json({ catalog });
  } catch (err) {
    next(err);
  }
});

// إضافة قسم جديد (مدير فقط)
router.post('/categories', requireRole('admin'), async (req, res, next) => {
  try {
    const { key, nameAr, sortOrder } = req.body;
    if (!key || !nameAr) return res.status(400).json({ error: 'اسم القسم ومفتاحه مطلوبان.' });
    const { rows } = await pool.query(
      `INSERT INTO categories (key, name_ar, sort_order) VALUES ($1,$2,$3) RETURNING *`,
      [key, nameAr, sortOrder || 0]
    );
    await logActivity(req.user, 'إضافة قسم غذائي جديد', nameAr);
    res.status(201).json({ category: rows[0] });
  } catch (err) {
    next(err);
  }
});

router.put('/categories/:id', requireRole('admin'), async (req, res, next) => {
  try {
    const { nameAr, sortOrder, isActive } = req.body;
    const { rows } = await pool.query(
      `UPDATE categories SET name_ar = COALESCE($1,name_ar),
        sort_order = COALESCE($2,sort_order), is_active = COALESCE($3,is_active)
       WHERE id = $4 RETURNING *`,
      [nameAr, sortOrder, isActive, req.params.id]
    );
    await logActivity(req.user, 'تعديل قسم غذائي', rows[0]?.name_ar);
    res.json({ category: rows[0] });
  } catch (err) {
    next(err);
  }
});

// إدارة عناصر الطعام — للمدير أو الموظف صاحب صلاحية manage_foods
router.post('/items', requirePermission('manage_foods'), async (req, res, next) => {
  try {
    const { categoryId, nameAr, sortOrder } = req.body;
    if (!categoryId || !nameAr) {
      return res.status(400).json({ error: 'القسم واسم العنصر مطلوبان.' });
    }
    const { rows } = await pool.query(
      `INSERT INTO food_items (category_id, name_ar, sort_order) VALUES ($1,$2,$3) RETURNING *`,
      [categoryId, nameAr, sortOrder || 0]
    );
    await logActivity(req.user, 'إضافة عنصر غذائي جديد', nameAr);
    res.status(201).json({ item: rows[0] });
  } catch (err) {
    next(err);
  }
});

router.put('/items/:id', requirePermission('manage_foods'), async (req, res, next) => {
  try {
    const { nameAr, categoryId, sortOrder, isActive } = req.body;
    const { rows } = await pool.query(
      `UPDATE food_items SET name_ar = COALESCE($1,name_ar),
        category_id = COALESCE($2,category_id), sort_order = COALESCE($3,sort_order),
        is_active = COALESCE($4,is_active)
       WHERE id = $5 RETURNING *`,
      [nameAr, categoryId, sortOrder, isActive, req.params.id]
    );
    await logActivity(req.user, 'تعديل عنصر غذائي', rows[0]?.name_ar);
    res.json({ item: rows[0] });
  } catch (err) {
    next(err);
  }
});

router.delete('/items/:id', requirePermission('manage_foods'), async (req, res, next) => {
  try {
    await pool.query('UPDATE food_items SET is_active = false WHERE id = $1', [req.params.id]);
    await logActivity(req.user, 'حذف/تعطيل عنصر غذائي', `id=${req.params.id}`);
    res.json({ message: 'تم حذف العنصر.' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
