const express = require('express');
const jwt = require('jsonwebtoken');
const pool = require('../db/pool');
const { verifyPassword, hashPassword } = require('../utils/password');
const { authenticate } = require('../middleware/auth');
const { logActivity } = require('../utils/audit');

const router = express.Router();

// تسجيل الدخول — لا يوجد تسجيل حساب جديد ذاتيًا، الحسابات ينشئها المدير فقط
router.post('/login', async (req, res, next) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'اسم المستخدم وكلمة المرور مطلوبان.' });
    }

    const { rows } = await pool.query(
      `SELECT id, username, password_hash, role, full_name, file_number, is_active
       FROM users WHERE username = $1`,
      [username]
    );
    const user = rows[0];

    if (!user || !user.is_active) {
      return res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غير صحيحة.' });
    }

    const ok = await verifyPassword(password, user.password_hash);
    if (!ok) {
      return res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غير صحيحة.' });
    }

    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role, fullName: user.full_name },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
    );

    await logActivity(user, 'تسجيل دخول');

    let permissions = [];
    if (user.role === 'staff') {
      const { rows: permRows } = await pool.query(
        'SELECT permission_key FROM staff_permissions WHERE user_id = $1',
        [user.id]
      );
      permissions = permRows.map((r) => r.permission_key);
    }

    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        role: user.role,
        fullName: user.full_name,
        fileNumber: user.file_number,
        permissions,
      },
    });
  } catch (err) {
    next(err);
  }
});

// تغيير كلمة المرور الخاصة بالمستخدم الحالي
router.post('/change-password', authenticate, async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword || newPassword.length < 8) {
      return res.status(400).json({ error: 'كلمة المرور الجديدة يجب ألا تقل عن 8 خانات.' });
    }

    const { rows } = await pool.query('SELECT password_hash FROM users WHERE id = $1', [req.user.id]);
    const ok = await verifyPassword(currentPassword, rows[0].password_hash);
    if (!ok) return res.status(401).json({ error: 'كلمة المرور الحالية غير صحيحة.' });

    const newHash = await hashPassword(newPassword);
    await pool.query('UPDATE users SET password_hash = $1, updated_at = now() WHERE id = $2', [
      newHash,
      req.user.id,
    ]);

    await logActivity(req.user, 'تغيير كلمة المرور الشخصية');
    res.json({ message: 'تم تحديث كلمة المرور بنجاح.' });
  } catch (err) {
    next(err);
  }
});

router.get('/me', authenticate, (req, res) => {
  res.json({ user: req.user });
});

module.exports = router;
