const express = require('express');
const pool = require('../db/pool');
const { authenticate, requireRole } = require('../middleware/auth');
const { requirePermission } = require('../middleware/rbac');
const { logActivity } = require('../utils/audit');

const router = express.Router();
router.use(authenticate);

// المريض يشاهد وجباته الخاصة
router.get('/me', requireRole('patient'), async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT id, name, items, note, status, created_at FROM meals
       WHERE patient_id = $1 ORDER BY created_at DESC`,
      [req.user.id]
    );
    res.json({ meals: rows });
  } catch (err) {
    next(err);
  }
});

// الموظف/المدير يشاهد وجبات مريض معيّن
router.get('/patients/:patientId', requirePermission('view_patients'), async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT id, name, items, note, status, created_at FROM meals
       WHERE patient_id = $1 ORDER BY created_at DESC`,
      [req.params.patientId]
    );
    res.json({ meals: rows });
  } catch (err) {
    next(err);
  }
});

// إنشاء وجبة جديدة لمريض
router.post('/patients/:patientId', requirePermission('create_meals'), async (req, res, next) => {
  try {
    const { name, items, note } = req.body;
    if (!name) return res.status(400).json({ error: 'اسم الوجبة مطلوب.' });
    const { rows } = await pool.query(
      `INSERT INTO meals (patient_id, name, items, note, created_by)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [req.params.patientId, name, items || {}, note || '', req.user.id]
    );
    await logActivity(req.user, 'إنشاء وجبة لمريض', `${name} — patient=${req.params.patientId}`);
    res.status(201).json({ meal: rows[0] });
  } catch (err) {
    next(err);
  }
});

// تعديل تفاصيل وجبة
router.put('/:id', requirePermission('edit_meals'), async (req, res, next) => {
  try {
    const { name, items, note } = req.body;
    const { rows } = await pool.query(
      `UPDATE meals SET name = COALESCE($1,name), items = COALESCE($2,items),
        note = COALESCE($3,note), updated_at = now()
       WHERE id = $4 RETURNING *`,
      [name, items, note, req.params.id]
    );
    await logActivity(req.user, 'تعديل وجبة', rows[0]?.name);
    res.json({ meal: rows[0] });
  } catch (err) {
    next(err);
  }
});

// تغيير حالة الوجبة: قيد التجهيز / جاهزة / تم التسليم
router.patch('/:id/status', requirePermission('change_meal_status'), async (req, res, next) => {
  try {
    const { status } = req.body;
    if (!['preparing', 'ready', 'delivered'].includes(status)) {
      return res.status(400).json({ error: 'حالة غير صالحة.' });
    }
    const { rows } = await pool.query(
      `UPDATE meals SET status = $1, updated_at = now() WHERE id = $2 RETURNING *`,
      [status, req.params.id]
    );
    await logActivity(req.user, 'تغيير حالة الوجبة', `${rows[0]?.name} → ${status}`);
    res.json({ meal: rows[0] });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
