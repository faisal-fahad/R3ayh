const express = require('express');
const pool = require('../db/pool');
const { authenticate, requireRole } = require('../middleware/auth');
const { hashPassword } = require('../utils/password');
const { logActivity } = require('../utils/audit');

const router = express.Router();
router.use(authenticate, requireRole('admin'));

const ALL_PERMISSIONS = [
  'view_patients', 'edit_patients', 'view_preferences', 'edit_preferences',
  'view_allergies', 'create_meals', 'edit_meals', 'change_meal_status', 'manage_foods',
];

async function attachPermissions(staffRows) {
  const ids = staffRows.map((s) => s.id);
  if (!ids.length) return staffRows;
  const { rows: perms } = await pool.query(
    `SELECT user_id, permission_key FROM staff_permissions WHERE user_id = ANY($1)`,
    [ids]
  );
  return staffRows.map((s) => ({
    ...s,
    permissions: perms.filter((p) => p.user_id === s.id).map((p) => p.permission_key),
  }));
}

router.get('/', async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT id, username, full_name, email, is_active, created_at FROM users
       WHERE role = 'staff' ORDER BY full_name`
    );
    res.json({ staff: await attachPermissions(rows), availablePermissions: ALL_PERMISSIONS });
  } catch (err) {
    next(err);
  }
});

router.post('/', async (req, res, next) => {
  try {
    const { username, password, fullName, email, permissions = [] } = req.body;
    if (!username || !password || !fullName) {
      return res.status(400).json({ error: 'اسم المستخدم وكلمة المرور والاسم الكامل مطلوبة.' });
    }
    const passwordHash = await hashPassword(password);
    const { rows } = await pool.query(
      `INSERT INTO users (username, password_hash, role, full_name, email, created_by)
       VALUES ($1,$2,'staff',$3,$4,$5) RETURNING id, username, full_name, email, is_active`,
      [username, passwordHash, fullName, email || null, req.user.id]
    );
    const staffId = rows[0].id;
    for (const key of permissions.filter((p) => ALL_PERMISSIONS.includes(p))) {
      await pool.query(
        `INSERT INTO staff_permissions (user_id, permission_key) VALUES ($1,$2)
         ON CONFLICT DO NOTHING`,
        [staffId, key]
      );
    }
    await logActivity(req.user, 'إضافة موظف جديد', fullName);
    res.status(201).json({ staff: rows[0] });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'اسم المستخدم مستخدم مسبقًا.' });
    next(err);
  }
});

router.put('/:id', async (req, res, next) => {
  try {
    const { fullName, email } = req.body;
    const { rows } = await pool.query(
      `UPDATE users SET full_name = COALESCE($1,full_name), email = COALESCE($2,email), updated_at = now()
       WHERE id = $3 AND role = 'staff' RETURNING id, username, full_name, email, is_active`,
      [fullName, email, req.params.id]
    );
    await logActivity(req.user, 'تعديل بيانات موظف', rows[0]?.full_name);
    res.json({ staff: rows[0] });
  } catch (err) {
    next(err);
  }
});

router.patch('/:id/status', async (req, res, next) => {
  try {
    const { isActive } = req.body;
    const { rows } = await pool.query(
      `UPDATE users SET is_active = $1, updated_at = now() WHERE id = $2 RETURNING id, full_name, is_active`,
      [isActive, req.params.id]
    );
    await logActivity(req.user, isActive ? 'تفعيل حساب موظف' : 'تعطيل حساب موظف', rows[0]?.full_name);
    res.json({ staff: rows[0] });
  } catch (err) {
    next(err);
  }
});

router.patch('/:id/credentials', async (req, res, next) => {
  try {
    const { username, password } = req.body;
    const fields = [];
    const values = [];
    let i = 1;
    if (username) { fields.push(`username = $${i++}`); values.push(username); }
    if (password) { fields.push(`password_hash = $${i++}`); values.push(await hashPassword(password)); }
    if (!fields.length) return res.status(400).json({ error: 'لا يوجد ما يتم تحديثه.' });
    values.push(req.params.id);
    const { rows } = await pool.query(
      `UPDATE users SET ${fields.join(', ')}, updated_at = now() WHERE id = $${i} RETURNING id, username`,
      values
    );
    await logActivity(req.user, 'تحديث بيانات دخول موظف', rows[0]?.username);
    res.json({ staff: rows[0] });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'اسم المستخدم مستخدم مسبقًا.' });
    next(err);
  }
});

// تحديد صلاحيات موظف (استبدال كامل للقائمة)
router.put('/:id/permissions', async (req, res, next) => {
  const client = await pool.connect();
  try {
    const { permissions = [] } = req.body;
    const valid = permissions.filter((p) => ALL_PERMISSIONS.includes(p));
    await client.query('BEGIN');
    await client.query('DELETE FROM staff_permissions WHERE user_id = $1', [req.params.id]);
    for (const key of valid) {
      await client.query('INSERT INTO staff_permissions (user_id, permission_key) VALUES ($1,$2)', [
        req.params.id,
        key,
      ]);
    }
    await client.query('COMMIT');
    await logActivity(req.user, 'تحديث صلاحيات موظف', `staff=${req.params.id}: ${valid.join(', ')}`);
    res.json({ permissions: valid });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
});

module.exports = router;
