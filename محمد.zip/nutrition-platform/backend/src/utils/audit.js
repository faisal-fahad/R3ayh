const pool = require('../db/pool');

/**
 * يسجل حدثًا في سجل النشاطات.
 * @param {object} actor - { id, username, role } للمستخدم الذي قام بالعملية
 * @param {string} action - وصف العملية، مثال: "إنشاء وجبة"
 * @param {string} [details] - تفاصيل إضافية اختيارية
 */
async function logActivity(actor, action, details = null) {
  try {
    await pool.query(
      `INSERT INTO audit_logs (user_id, username, role, action, details)
       VALUES ($1, $2, $3, $4, $5)`,
      [actor?.id || null, actor?.username || 'غير معروف', actor?.role || null, action, details]
    );
  } catch (err) {
    // لا نكسر الطلب الأساسي إذا فشل تسجيل النشاط، لكن نطبع الخطأ
    console.error('audit log failed:', err.message);
  }
}

module.exports = { logActivity };
