require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const authRoutes = require('./routes/auth.routes');
const patientsRoutes = require('./routes/patients.routes');
const preferencesRoutes = require('./routes/preferences.routes');
const foodsRoutes = require('./routes/foods.routes');
const mealsRoutes = require('./routes/meals.routes');
const staffRoutes = require('./routes/staff.routes');
const auditRoutes = require('./routes/audit.routes');

const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '1mb' }));

// حد لعدد محاولات تسجيل الدخول لتقليل هجمات التخمين
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'محاولات كثيرة جدًا، حاول لاحقًا.' },
});
app.use('/api/auth/login', loginLimiter);

app.use('/api/auth', authRoutes);
app.use('/api/patients', patientsRoutes);
app.use('/api', preferencesRoutes); // /api/me/preferences و /api/patients/:id/preferences
app.use('/api', foodsRoutes);       // /api/catalog, /api/categories, /api/items
app.use('/api/meals', mealsRoutes);
app.use('/api/staff', staffRoutes);
app.use('/api/audit-logs', auditRoutes);

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

// معالج أخطاء موحّد — لا يُظهر تفاصيل داخلية للمستخدم
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: 'حدث خطأ غير متوقع، حاول مرة أخرى.' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`الخادم يعمل على المنفذ ${PORT}`));
