const pool = require('../db/pool');

/**
 * يتحقق أن الموظف يملك صلاحية معينة قبل تنفيذ الإجراء.
 * المدير (admin) يتجاوز هذا التحقق دائمًا.
 * صلاحيات متاحة: view_patients, edit_patients, view_preferences,
 *   edit_preferences, view_allergies, create_meals, edit_meals,
 *   change_meal_status, manage_foods
 */
function requirePermission(permissionKey) {
  return async (req, res, next) => {
    if (req.user.role === 'admin') return next();

    if (req.user.role !== 'staff') {
      return res.status(403).json({ error: 'لا تملك صلاحية الوصول إلى هذا المورد.' });
    }

    try {
      const { rows } = await pool.query(
        `SELECT 1 FROM staff_permissions WHERE user_id = $1 AND permission_key = $2`,
        [req.user.id, permissionKey]
      );
      if (rows.length === 0) {
        return res.status(403).json({ error: 'لم يمنحك المدير صلاحية القيام بهذا الإجراء.' });
      }
      next();
    } catch (err) {
      next(err);
    }
  };
}

module.exports = { requirePermission };
