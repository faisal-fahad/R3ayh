const jwt = require('jsonwebtoken');

function authenticate(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'يجب تسجيل الدخول للوصول إلى هذا المورد.' });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload; // { id, username, role, fullName }
    next();
  } catch (err) {
    return res.status(401).json({ error: 'الجلسة غير صالحة أو منتهية، يرجى تسجيل الدخول مجددًا.' });
  }
}

/** يسمح فقط لأدوار معينة بالوصول */
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'لا تملك صلاحية الوصول إلى هذا المورد.' });
    }
    next();
  };
}

module.exports = { authenticate, requireRole };
