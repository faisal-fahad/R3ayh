-- ============================================================
-- منصة تخصيص وجبات مرضى الكلى — مخطط قاعدة البيانات (PostgreSQL)
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- الأدوار: مريض / موظف / مدير
CREATE TABLE users (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username        VARCHAR(64)  UNIQUE NOT NULL,
  password_hash   TEXT NOT NULL,
  role            VARCHAR(16)  NOT NULL CHECK (role IN ('patient','staff','admin')),
  full_name       VARCHAR(120) NOT NULL,
  email           VARCHAR(160),
  file_number     VARCHAR(40) UNIQUE,       -- خاص بالمرضى فقط
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  created_by      UUID REFERENCES users(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- صلاحيات الموظفين (كل صف = صلاحية ممنوحة لموظف)
CREATE TABLE staff_permissions (
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  permission_key  VARCHAR(64) NOT NULL,
  PRIMARY KEY (user_id, permission_key)
);
-- مفاتيح الصلاحيات المتاحة (تستخدم كقيم لـ permission_key):
--  view_patients, edit_patients, view_preferences, edit_preferences,
--  view_allergies, create_meals, edit_meals, change_meal_status, manage_foods

-- أقسام الطعام (كربوهيدرات، بروتين، خضروات ...)
CREATE TABLE categories (
  id          SERIAL PRIMARY KEY,
  key         VARCHAR(32) UNIQUE NOT NULL,   -- carbs, protein, vegetables, fiber, fats, fruits, drinks, extras
  name_ar     VARCHAR(80) NOT NULL,
  sort_order  INT NOT NULL DEFAULT 0,
  is_active   BOOLEAN NOT NULL DEFAULT TRUE
);

-- عناصر الطعام داخل كل قسم (يديرها المدير)
CREATE TABLE food_items (
  id          SERIAL PRIMARY KEY,
  category_id INT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  name_ar     VARCHAR(120) NOT NULL,
  sort_order  INT NOT NULL DEFAULT 0,
  is_active   BOOLEAN NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- تفضيل المريض لكل عنصر طعام
CREATE TABLE preferences (
  id            SERIAL PRIMARY KEY,
  patient_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  food_item_id  INT NOT NULL REFERENCES food_items(id) ON DELETE CASCADE,
  status        VARCHAR(16) NOT NULL CHECK (status IN ('want','not_want','not_eat','allergy')),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (patient_id, food_item_id)
);

-- ملاحظة المريض الخاصة بكل قسم (مثال: "أفضل الدجاج مشويًا")
CREATE TABLE section_notes (
  patient_id   UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category_id  INT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  note         TEXT NOT NULL DEFAULT '',
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (patient_id, category_id)
);

-- الملاحظات العامة للمريض
CREATE TABLE general_notes (
  patient_id  UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  note        TEXT NOT NULL DEFAULT '',
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- الوجبات التي يجهزها فريق العيادة للمريض
CREATE TABLE meals (
  id            SERIAL PRIMARY KEY,
  patient_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name          VARCHAR(80) NOT NULL,          -- مثال: وجبة الغداء
  items         JSONB NOT NULL DEFAULT '{}',   -- { "carbs": "رز أبيض", "protein": "دجاج على الفحم", ... }
  note          TEXT DEFAULT '',
  status        VARCHAR(16) NOT NULL DEFAULT 'preparing'
                CHECK (status IN ('preparing','ready','delivered')),
  created_by    UUID REFERENCES users(id),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- سجل النشاطات (Audit Log)
CREATE TABLE audit_logs (
  id          BIGSERIAL PRIMARY KEY,
  user_id     UUID REFERENCES users(id),
  username    VARCHAR(64),
  role        VARCHAR(16),
  action      VARCHAR(64) NOT NULL,
  details     TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_preferences_patient ON preferences(patient_id);
CREATE INDEX idx_food_items_category ON food_items(category_id);
CREATE INDEX idx_meals_patient ON meals(patient_id);
CREATE INDEX idx_audit_logs_created ON audit_logs(created_at DESC);

-- ============ بيانات أولية ============

INSERT INTO categories (key, name_ar, sort_order) VALUES
  ('carbs',      'الكربوهيدرات',   1),
  ('protein',    'البروتين',        2),
  ('vegetables', 'الخضروات',        3),
  ('fiber',      'الألياف',         4),
  ('fats',       'الدهون والإضافات',5),
  ('fruits',     'الفواكه',         6),
  ('drinks',     'المشروبات',       7),
  ('extras',     'الإضافات',        8);

INSERT INTO food_items (category_id, name_ar, sort_order) VALUES
  ((SELECT id FROM categories WHERE key='carbs'),  'رز أبيض', 1),
  ((SELECT id FROM categories WHERE key='carbs'),  'رز أحمر', 2),
  ((SELECT id FROM categories WHERE key='carbs'),  'مكرونة', 3),
  ((SELECT id FROM categories WHERE key='carbs'),  'بطاطس', 4),
  ((SELECT id FROM categories WHERE key='carbs'),  'خبز', 5),
  ((SELECT id FROM categories WHERE key='protein'), 'دجاج مشوي', 1),
  ((SELECT id FROM categories WHERE key='protein'), 'دجاج على الفحم', 2),
  ((SELECT id FROM categories WHERE key='protein'), 'لحم', 3),
  ((SELECT id FROM categories WHERE key='protein'), 'سمك', 4),
  ((SELECT id FROM categories WHERE key='protein'), 'بيض', 5),
  ((SELECT id FROM categories WHERE key='vegetables'), 'خس', 1),
  ((SELECT id FROM categories WHERE key='vegetables'), 'خيار', 2),
  ((SELECT id FROM categories WHERE key='vegetables'), 'جزر', 3),
  ((SELECT id FROM categories WHERE key='vegetables'), 'بروكلي', 4),
  ((SELECT id FROM categories WHERE key='vegetables'), 'كوسة', 5),
  ((SELECT id FROM categories WHERE key='vegetables'), 'طماطم', 6),
  ((SELECT id FROM categories WHERE key='vegetables'), 'فاصوليا', 7),
  ((SELECT id FROM categories WHERE key='fats'), 'زيت الزيتون', 1),
  ((SELECT id FROM categories WHERE key='fats'), 'صوص', 2),
  ((SELECT id FROM categories WHERE key='drinks'), 'ماء', 1),
  ((SELECT id FROM categories WHERE key='drinks'), 'عصير طبيعي', 2),
  ((SELECT id FROM categories WHERE key='extras'), 'بهارات', 1),
  ((SELECT id FROM categories WHERE key='extras'), 'صوص إضافي', 2);

-- لا يُنشأ أي حساب مدير هنا تلقائيًا. شغّل بعد الترحيل:
--   npm run seed:admin -- <username> <password>
-- لإنشاء أول حساب مدير بكلمة مرور مشفّرة فعليًا (راجع src/scripts/seedAdmin.js).
